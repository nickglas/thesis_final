# RQ1.1 Experimental Design

## From First Principles

---

## 1. Recommended RQ1.1

### Research Question

> **RQ1.1:** Which coarse architectural stage boundaries provide the most suitable two-part microservice decompositions of ResNet-18 under controlled local execution, and how do their latency and boundary-crossing costs compare to monolithic inference?

### Justification

This is a **coarse-boundary selection question**, not only an overhead-characterization question. It asks:

1. **How do coarse two-part decompositions compare against monolithic inference?**
2. **How do latency and boundary-crossing costs vary across coarse architectural boundaries?**
3. **Which boundaries are most suitable to carry forward into later thesis stages?**

This framing is stronger for the thesis than a pure "single boundary overhead" characterization because:

- It preserves **RQ1.1 as a selection stage**, which is necessary for later carry-forward logic.
- It still quantifies the cost of a single microservice boundary under controlled conditions.
- It compares **architecturally meaningful coarse boundaries** rather than a single arbitrary split.
- It supports a later dependency chain in which selected boundaries feed refinement and multi-microservice stages.

The question is deliberately scoped to:

- a single model (**ResNet-18**),
- a single communication protocol (**gRPC**),
- single-request inference (**batch size 1**),
- and localhost communication under a controlled local setup.

These constraints are deliberate. They eliminate unnecessary confounds and make the results interpretable while preserving thesis relevance.

---

## 2. Recommended Experiment Design

### Design Type: Controlled Coarse-Boundary Screening

The experiment is a **single-factor repeated-measures design**:

- **Independent variable:** Inference configuration (**5 levels: 1 monolithic baseline + 4 coarse architectural split points**)
- **Dependent variable:** End-to-end inference latency
- **Within-subjects:** All conditions tested on the same hardware with the same inputs

This is the strongest design because:

- it keeps the main experiment focused on **coarse architectural boundary selection**
- it avoids confounding multiple variables at once
- it maintains a clean comparison against monolithic execution
- it supports later thesis stages by yielding a carry-forward decision rather than only a descriptive characterization

### Conditions

**Condition 0 — Monolithic Baseline**
Full ResNet-18 executes as a direct in-process function call. No networking, no serialization, no process boundary. This is the gold-standard reference: the minimum possible inference latency with zero distribution overhead.

**Condition 1 — Split after layer1**

- Service A: initial block + layer1
- Service B: layer2 through fc
- Intermediate tensor: 64 × 56 × 56 = 200,704 floats ≈ 784 KB
- Compute balance: early-side light, later-side heavy

**Condition 2 — Split after layer2**

- Service A: initial block + layer1 + layer2
- Service B: layer3 through fc
- Intermediate tensor: 128 × 28 × 28 = 100,352 floats ≈ 392 KB
- Compute balance: moderately balanced

**Condition 3 — Split after layer3**

- Service A: initial block + layer1–layer3
- Service B: layer4 + avgpool + fc
- Intermediate tensor: 256 × 14 × 14 = 50,176 floats ≈ 196 KB
- Compute balance: later stage still meaningful, but more work shifted to A

**Condition 4 — Split after layer4 (before avgpool + fc)**

- Service A: initial block + layer1–layer4
- Service B: avgpool + fc
- Intermediate tensor: 512 × 7 × 7 = 25,088 floats ≈ 98 KB
- Compute balance: highly late split, likely degenerate on compute balance

### Why These 4 Split Points

These are the thesis-facing **coarse architectural stage boundaries** in ResNet-18. They correspond to meaningful named module groups and provide a clean stage-level sweep.

This scope is preferred over adding the earliest stem split because:

- the main purpose of RQ1.1 is **coarse screening and selection**
- mid- and late-stage boundaries are the more meaningful coarse candidates for later thesis stages
- the earliest split risks dominating figures in a trivial way due to very large activations and poor balance
- including it in the main sweep would make the story look more like an exhaustive characterization exercise than a thesis-guided selection stage

If the stem split is studied at all, it should be treated only as:

- appendix material,
- preliminary calibration,
- or an exploratory sensitivity point not part of the main RQ1.1 thesis-facing sweep.

### Execution Architecture

**Monolithic (Condition 0):**

```text
[Client Process]
  input_tensor → model(input_tensor) → output_tensor
  ↑ timing start              ↑ timing stop
```

**Split (Conditions 1–4):**

```text
[Client/Service A Process]          [Service B Process (separate OS process)]
  t_start
  input_tensor → part_A(input)      [service_a_compute_ms]
                    ↓
  t_boundary_start
              serialize(intermediate)  [request_serialize_ms]
                    ↓
              ──── gRPC Infer() ────→  deserialize(intermediate) [request_deserialize_ms]
                                       part_B(intermediate)      [service_b_compute_ms]
                                       serialize(output)         [response_serialize_ms]
              ←─── gRPC response ──
              deserialize(output)      [response_deserialize_ms]
  t_boundary_end                       [boundary_crossing_ms = t_boundary_end - t_boundary_start]
  t_end                                [end_to_end_ms = t_end - t_start]

  Server-side sub-timings (deserialize_ms, compute_ms, serialize_ms)
  are embedded in the gRPC InferResponse proto message.
```

### Key Design Decisions

**Service B is a separate OS process**, not a thread or in-process mock. This represents a real microservice boundary with true process isolation.

**Communication is via gRPC over localhost (127.0.0.1).** This removes real-network variability while preserving:

- real serialization,
- real RPC framing,
- real process-boundary overhead,
- and real inter-process communication.

Localhost therefore gives a lower-bound environment for boundary-related overhead.

**The monolithic baseline uses no gRPC.** It is a direct `model(input)` call. This is intentional: RQ1.1 asks what the total cost of introducing a microservice boundary is, compared to having no boundary at all. A gRPC-wrapped monolith would answer a different question.

**Timing is measured at the client/orchestrator.** This captures the full end-to-end latency seen by a caller, including compute, serialization, framework overhead, process-boundary crossing, and response reconstruction.

### Why gRPC

gRPC with Protocol Buffers is an appropriate default because it is:

- efficient and binary
- widely used in microservice systems
- based on a well-known transport stack
- supported well in Python
- a defensible choice for a thesis that wants microservice relevance without turning protocol choice into a separate experiment

### Hardware and Software

- **CPU inference only** for RQ1.1. GPU inference introduces additional confounds such as kernel launches, host-device transfers, and scheduling artifacts.
- **Single machine, localhost communication.** Real network effects are outside the scope of this first stage.
- **PyTorch in eval mode, `torch.no_grad()`.**
- **FP32 precision.**
- **Batch size 1.**
- **Fixed deterministic input tensor** for the main benchmark. This reduces variance and keeps the experiment focused on boundary effects rather than input heterogeneity.

### CPU-Behaviour Stabilisation Controls

To reduce run-to-run variance and improve measurement reproducibility, the benchmark applies environment-aware CPU-behaviour controls before any measurement begins. These follow standard practice in performance benchmarking literature (Beyer, Löwe & Wendler, "Reliable benchmarking: requirements and solutions", STTT 2019; LLVM Benchmarking Tips; Cui & Pericas, "Characterizing and Mitigating Performance Variability in Parallel Applications on Modern HPC multicore Systems", ICS 2025).

All controls are fully configurable from the `cpu_stabilisation:` section of the YAML config. We provide three standard configurations, each representing a different measurement mode:

1. **configs/rq1/1.1/rq1_1_fully_controlled.yaml**: The strict thesis-facing benchmark mode. Enforces absolute minimisation of contention by pinning to 1 physical core with 1 thread, alongside explicit requests for "performance" CPU governor and turbo boost disabling. Use this for the most robust statistical outcomes.
2. **configs/rq1/1.1/rq1_1_threaded.yaml**: The multi-core mode. Limits PyTorch and BLAS to 4 threads executing on 4 pinned physical cores, preventing SMT and cross-node migration while representing standard multi-core deployment scenarios. Governor and turbo controls are not set.
3. **configs/rq1/1.1/rq1_1_experimental.yaml**: A non-stabilised smoke test profile designed for fast pipeline validation, employing minimal iterations (1 round, 3 warmup, 5 measured) with only 2 conditions (monolithic + split_after_layer2). Process priority is disabled.

**Applied controls (config-driven):**

| Control                           | Config key                                                     | Fully Controlled Default | Threaded Default | Rationale                                                                                                                                                                                                        |
| --------------------------------- | -------------------------------------------------------------- | ------------------------ | ---------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| PyTorch intra-op threads          | `threading.pytorch_intra_op`                                   | 1                        | 4                | Single-threaded mode eliminates all intra-op synchronisation variance. Threaded mode represents a standard multi-core scenario.                                                                                  |
| PyTorch inter-op threads          | `threading.pytorch_inter_op`                                   | 1                        | 1                | Single-input sequential inference; no benefit from graph-level parallelism. Eliminates inter-op scheduling variance.                                                                                             |
| OMP_NUM_THREADS / MKL_NUM_THREADS | `threading.omp_num_threads` / `threading.mkl_num_threads`      | 1                        | 4                | Ensures underlying BLAS and OpenMP libraries respect the same thread count. Propagated to Service B via environment.                                                                                             |
| OPENBLAS_NUM_THREADS              | `threading.openblas_num_threads`                               | 1                        | 4                | Controls OpenBLAS thread count alongside OMP and MKL. Propagated to Service B via environment.                                                                                                                   |
| CPU affinity (core pinning)       | `affinity.enabled`, `affinity.num_cores`, `affinity.avoid_smt` | true / 1 / true          | true / 4 / true  | Avoids OS migration across cores, eliminates L1/L2 cache thrashing from migration, and avoids SMT contention. `explicit_cpus` can override auto-detection. Applied via `os.sched_setaffinity()`.                 |
| Process priority (nice)           | `priority.enabled`, `priority.nice_value`                      | true / -5                | true / -5        | Raises process priority where privileges allow. Falls back gracefully without root.                                                                                                                              |
| Service B thread settings         | Propagated via env vars                                        | Mirrors parent           | Mirrors parent   | `PYTORCH_INTRA_OP_THREADS` and `PYTORCH_INTER_OP_THREADS` are propagated to the Service B subprocess. Service B reads these and calls `torch.set_num_threads()` / `torch.set_num_interop_threads()` accordingly. |

**Optional controls (Linux native only, require root):**

| Control                | Config key                                         | Fully Controlled Default | Threaded Default      | Note                                                                                                                                                                                                                |
| ---------------------- | -------------------------------------------------- | ------------------------ | --------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| CPU frequency governor | `governor.set_governor`, `governor.requested_mode` | true / "performance"     | false / "performance" | When `set_governor: true`, writes the requested governor to all CPU cores via cpufreq sysfs. Unavailable on WSL2/Hyper-V; CPU frequency is managed by the Windows host power plan.                                  |
| Turbo boost disable    | `turbo.disable_turbo`                              | true                     | false                 | When true, writes to `intel_pstate/no_turbo` or `cpufreq/boost`. Unavailable on WSL2/Hyper-V. On the AMD Ryzen 7 7800X3D, the 3D V-Cache design exhibits less frequency-induced variance than typical desktop CPUs. |
| ASLR                   | Detect only (not configurable)                     | —                        | —                     | Address space layout randomisation is detected and recorded. Impact on wall-clock inference latency is negligible.                                                                                                  |

**Metadata recording:** Every control records a structured `{requested, detected, applied, error}` metadata block in `environment.json`, ensuring full auditability. If the environment cannot apply a requested setting (e.g. no root, no sysfs), the exact reason is captured.

**Fairness guarantee:** All controls are applied symmetrically to all conditions. Thread counts, affinity, and environment variables are identical for monolithic and split configurations. The stabilisation layer runs once at benchmark startup, before any condition is executed.

---

## 3. Rejected Alternatives

### Alternative A: Single Representative Split Point

**Design:** Pick one split point, compare monolithic vs. split.

**Why rejected:** This does not answer the thesis-facing RQ1.1, because it does not perform a coarse architectural screening and cannot support a carry-forward boundary decision.

### Alternative B: Exhaustive Layer-by-Layer Sweep

**Design:** Test every possible layer as a split point.

**Why rejected:** This is too fine-grained for the purpose of RQ1.1. Many split points would be architecturally unhelpful, hard to interpret, or redundant. It would weaken the thesis story by making the experiment look like a blind exhaustive search rather than an architecturally grounded screening stage.

### Alternative C: Include Stem / Initial-Block Split in the Main Sweep

**Design:** Add a split after the stem / initial block.

**Why rejected for the main sweep:** Although defensible as an extreme sensitivity point, it is not the strongest thesis-facing default because it risks:

- trivially large activation-transfer burden
- poor compute balance
- visually dominating plots
- pulling the study toward characterization rather than selection

It may be retained only as appendix or exploratory material.

### Alternative D: Multiple Decomposition Paradigms

**Design:** Compare layer partitioning against tensor parallelism, pipeline parallelism, or other paradigms.

**Why rejected:** This broadens the thesis beyond what RQ1.1 needs and makes fair comparison much harder. RQ1.1 should stay focused on coarse sequential two-part decomposition.

### Alternative E: Multiple Communication Protocols

**Design:** Cross architectural boundary with protocol choice.

**Why rejected:** Protocol comparison is a separate concern. RQ1.1 should fix the protocol and study boundary choice.

### Alternative F: Include Containerization or Kubernetes

**Design:** Run RQ1.1 in Docker or Kubernetes.

**Why rejected:** RQ1.1 should isolate decomposition and boundary effects under controlled local execution. Container and orchestration effects belong later.

---

## 4. Measurement Contract

### Primary Metric

**Mean end-to-end inference latency (wall-clock time, milliseconds)**

- **Definition:** Time from the moment the input tensor is available in client memory to the moment the output tensor is available in client memory.
- **Timing instrument:** `time.perf_counter()`
- **Monolithic timing boundary:** Immediately before `model(input)` to immediately after return.
- **Split timing boundary:** Immediately before `part_A(input)` to immediately after client-side response deserialization.
- **Inclusions:** All computation, all serialization/deserialization, all gRPC overhead, all inter-process communication.
- **Exclusions:** Model loading, service startup, and channel establishment.

**Why this is primary:** RQ1.1 is a carry-forward selection stage. The selection decision should be based on the average per-request cost under repeated controlled trials. Mean end-to-end latency is therefore the most appropriate primary ranking metric.

### Secondary Metrics

**Median end-to-end latency** — Robust central-tendency companion to the mean.

**p95 end-to-end latency** — Captures tail behavior.

**Standard deviation of end-to-end latency** — Captures variability.

**Activation-transfer burden** — `activation_bytes_mean`: captures how much intermediate data is handed off across the boundary.

**Compute time per side** — `service_a_compute_ms_mean` and `service_b_compute_ms_mean`.

**Overhead ratio** — `(split_mean - monolith_mean) / monolith_mean × 100%`

### Boundary-Crossing Metric

Use:

```
boundary_crossing_ms
```

not the looser phrase _communication overhead_, unless explicitly clarified.

**Definition:** Wall-clock interval measured entirely client-side, from the start of serializing the intermediate tensor on Service A / caller side to the completion of response deserialization on the caller side.

**Purpose:** This metric captures the compound cost of crossing the service boundary. It includes:

- request serialization (client-side)
- gRPC framework overhead and RPC round-trip
- request deserialization (server-side)
- Service B compute
- response serialization (server-side)
- response deserialization (client-side)

Server-side sub-timings (`deserialize_ms`, `compute_ms`, `serialize_ms`) are embedded in the gRPC response proto and recorded as diagnostic metrics (`request_deserialize_ms`, `service_b_compute_ms`, `response_serialize_ms`). The client also records `request_serialize_ms` and `response_deserialize_ms` from its own timing.

This metric should not be described as a pure transport-only communication metric.

### Diagnostic-Only Metrics (Not for Main Claims)

These are recorded in `raw_iterations.csv` but should remain diagnostic:

- `request_serialize_ms` — client-side, time to serialize intermediate tensor to bytes
- `request_deserialize_ms` — server-reported, time to deserialize intermediate tensor from bytes
- `response_serialize_ms` — server-reported, time to serialize output tensor to bytes
- `response_deserialize_ms` — client-side, time to deserialize output tensor from bytes
- CPU utilization (not currently recorded)
- memory usage (not currently recorded)
- system timestamp (not currently recorded)

### Why Diagnostic Metrics Are Separate

These sub-timings are useful for diagnosis and interpretation, but they may overlap or fail to sum cleanly. Thesis claims should therefore rest primarily on:

- end-to-end latency,
- activation-transfer burden,
- compute distribution,
- and the compound boundary-crossing interval.

### Functional Equivalence Check

Before any performance measurement, verify that:

- monolithic and split configurations produce numerically equivalent outputs for the same inputs
- all configurations use identical weights
- outputs match on a small set of test inputs (configurable, default 5 inputs, atol = 1e-5)

This is a **mandatory precondition**, not an optional check:

1. **Local validation** (PartA → PartB in-process) is run by `run_experiment.py` before the benchmark starts. If any split fails, the process exits (`sys.exit(1)`).
2. **gRPC validation** (PartA → gRPC → Service B → response) is run by the benchmark runner for each split condition in round 1, after Service B startup. If any split fails, the runner raises `RuntimeError` and the benchmark aborts.
3. Both validation results are saved as `parity_validation.json` (with separate `local_validation` and `grpc_validation` sections) recording tolerance, input count, max absolute difference, and pass/fail per split point.
4. There is no `--skip-validation` flag. Parity cannot be bypassed.

---

## 5. Benchmark Process

### Benchmark Conditions

All parameters below are driven by YAML configuration. The **fully controlled** profile (`configs/rq1/1.1/rq1_1_fully_controlled.yaml`) is the thesis-facing benchmark mode. The threaded and experimental profiles override specific values as described in the CPU-Behaviour Stabilisation Controls section.

| Parameter                  | Value (fully controlled)                             | Justification                                          |
| -------------------------- | ---------------------------------------------------- | ------------------------------------------------------ |
| Model                      | ResNet-18 (torchvision, pretrained)                  | Standard, interpretable, manageable on CPU             |
| Input shape                | (1, 3, 224, 224), FP32                               | Standard ImageNet shape                                |
| Input data                 | Fixed deterministic tensor (seed 42)                 | Reduces variance                                       |
| Batch size                 | 1                                                    | Measures per-request latency                           |
| Device                     | CPU                                                  | Avoids GPU confounds                                   |
| Inference mode             | `model.eval()`, `torch.no_grad()`                    | Standard inference                                     |
| Communication              | gRPC, localhost (127.0.0.1:50051), unary RPC         | Appropriate microservice baseline                      |
| Serialization              | Protocol Buffers with raw-bytes tensor payload       | Efficient and standard                                 |
| Service deployment         | Separate OS processes                                | Real process boundary                                  |
| gRPC server workers        | 1 (`max_workers=1`)                                  | Single-threaded server, no server-side parallelism     |
| OS power profile           | High performance if possible                         | Reduces frequency-scaling variance                     |
| CPU frequency              | Performance governor requested (unavailable on WSL2) | Reduces thermal and scaling artifacts                  |
| Turbo boost                | Disable requested (unavailable on WSL2)              | Reduces frequency-induced variance                     |
| PyTorch threads (intra-op) | 1                                                    | Eliminates all intra-op synchronisation variance       |
| PyTorch threads (inter-op) | 1                                                    | No graph parallelism needed for single-input inference |
| OMP / MKL / OpenBLAS       | All set to 1                                         | Ensures BLAS libraries respect the same thread count   |
| CPU affinity               | 1 physical core, SMT excluded                        | Avoids OS migration and L1/L2 cache thrashing          |
| Process priority           | nice = -5                                            | Raises priority where privileges allow                 |

### Warmup Policy

Warmup is explicit and condition-specific.

**Protocol:**

1. Before each condition in each round, run W = 50 warmup iterations.
2. During warmup, monitor latency stabilisation using a trailing-window coefficient of variation (CV) check (window = 10 iterations, threshold CV < 0.02). The CV uses population standard deviation (`ddof=0`), appropriate for a running window estimate.
3. All W warmup iterations are always executed (minimum guarantee), regardless of whether stabilisation is reached earlier.
4. Record the stabilisation point (or lack thereof) as an artifact in `warmup_calibration.json`.
5. If stabilisation is not reached within W iterations, log a warning but proceed.
6. Exclude all warmup iterations from measurement summaries.

**Rationale:** A fixed warmup count is the simplest defensible approach for CPU inference. The empirical stabilisation check provides evidence that W = 50 is sufficient, without introducing adaptive warmup complexity.

### Measured-Run Policy

- **Per condition per round:** M = 200 measured iterations
- **Per condition total:** 5 rounds × 200 = 1,000 measured iterations

This is intentionally ambitious and should be kept.

### Repetition Structure

**Design:** Nested repetition with R = 5 independent rounds.

```
For each round r in 1..R:
    Generate condition-order permutation π_r (seeded: Random(seed + r))
    For each condition c in π_r:
        Start Service B subprocess (if split condition)
        Wait for gRPC channel ready (if split condition)
        Run gRPC parity validation (split conditions, round 1 only)
        Run W warmup iterations with calibration check (discarded)
        Run M measured iterations (recorded to raw_iterations.csv)
        Shut down Service B (if split condition)
        Cooldown pause: 5 seconds
```

### Why Keep This Strong Repetition Structure

The proposed structure is operationally ambitious, but it should be preserved because it gives:

- strong statistical stability
- tight confidence intervals
- visibility into variance and distribution shape
- better protection against temporal and thermal drift
- more defensible thesis reporting

This is one of the strongest parts of the design and worth keeping.

### Ordering Strategy

**Within each round:** Conditions are tested in a randomized order using fixed seeds. This avoids fixed-order bias while keeping each condition in a clean measurement block.

### Fairness Controls

- Same model weights across all conditions
- Same input tensor across all conditions
- Same hardware
- Same software environment
- Same inference mode
- Same precision
- No concurrent benchmark workload
- Cooldown between conditions
- No condition-specific optimization path

### Process Asymmetry Note

In split conditions, Service A and Service B run in separate processes. Monolithic runs in a single process. This asymmetry is intentional. The benchmark is supposed to measure the full cost of introducing a real service boundary, not a process-symmetric toy comparison.

### Reproducibility Controls

- Fixed seeds
- Full environment recording
- System-state recording
- Raw per-iteration artifact preservation
- Code version recording
- Single config file determining all benchmark behavior

### Statistical Reporting

**Per condition:**

- Mean latency (primary)
- Median latency
- Standard deviation (sample, `ddof=1`)
- p5, p25, p75, p95, p99
- Min, max
- 95% confidence intervals (t-distribution, `df=n-1`)
- Means of secondary metrics: `service_a_compute_ms`, `service_b_compute_ms`, `boundary_crossing_ms`, `activation_bytes`

**Per round × condition:**

- Mean, median, std, p95 per round
- Enables visual inspection of drift and round-to-round stability

**Cross-round consistency (primary stability evidence):**

- Standard deviation of round means (sample, `ddof=1`)
- Range of round means
- Coefficient of variation of round means
- Saved as `round_consistency.json`
- This is more defensible than per-iteration p-values for assessing result stability

**Cross-condition comparisons:**

- `split_mean - monolith_mean`
- relative overhead ratio
- effect sizes (Cohen's d)
- Cohen's d interpretation (negligible / small / medium / large)

**Significance testing (supplementary, with caveats):**

- Mann-Whitney U and p-values are reported but de-emphasised
- With N = 1,000 per-iteration observations, p-values are inflated and near-zero for any non-trivial difference
- These should not be cited as strong evidence of practical significance
- Cross-round consistency and confidence intervals are preferred

**Visualization:**

- `latency_boxplot.png` — box plot per condition
- `latency_violin.png` — violin plot with means and medians
- `overhead_vs_activation.png` — scatter: activation KB vs overhead ms
- `stationarity.png` — per-iteration time series per condition, ordered by (round, iteration)

---

## 6. Carry-Forward Selection Rule

RQ1.1 must explicitly include a predeclared carry-forward rule.

**Primary criterion:** Minimize `end_to_end_latency_ms_mean`

**Near-best window:** Define a near-best window around the best observed split mean (configurable, default 5%).

**Degeneracy filter:** Mark candidates as compute-degenerate if the minor side contributes less than the configured threshold (default 10%) of total split compute (service_a_compute + service_b_compute).

**Tie-break:** Among valid near-best non-degenerate candidates, prefer lower `activation_bytes_mean`.

**Selection logic (executed in strict order):**

1. Identify `raw_fastest`: the split with lowest mean end-to-end latency.
2. Identify near-best candidates: all splits within the near-best window.
3. Apply degeneracy filter to near-best candidates.
4. If at least one non-degenerate near-best candidate exists:
   - `selected_main` = best by (mean_ms, activation_bytes_mean).
   - `selected_reference` = next best from same set, if any.
5. If ALL near-best candidates are degenerate:
   - `selected_main` = None. No candidate is promoted.
   - `selected_reference` = `raw_fastest` (retained as reference only, explicitly flagged).
   - `fallback_used` = True with an explicit note in the carry-forward artifact and report.
6. No hidden fallback: a degenerate candidate is never silently promoted to `selected_main`.

**Output categories:** The report must clearly distinguish:

- raw fastest boundary
- selected main candidate (may be None)
- selected reference candidate
- rejected candidates
- whether the degenerate fallback was invoked

This is essential because RQ1.1 is not only descriptive; it is a selection stage for later thesis steps.

---

## 7. Thesis Interpretation

### What This Experiment Supports Claiming

- Coarse architectural boundaries differ in end-to-end latency penalty relative to monolithic inference.
- Coarse boundaries differ in activation-transfer burden and compute distribution.
- A raw fastest boundary is not automatically the best thesis-facing carry-forward boundary if it is compute-degenerate or otherwise excluded by the predeclared selection rule.
- The measured boundary-crossing interval provides a lower-bound view of service-boundary cost under localhost execution.
- The results support a coarse local carry-forward decision for later thesis stages.

### What This Experiment Does NOT Support Claiming

- A universal best partitioning strategy
- A production-optimal deployment recommendation
- A cloud deployment result
- Proof that distributed inference improves latency
- Generalization to GPU inference
- Generalization to all model families
- A pure communication-transport decomposition unless that is separately and cleanly isolated

### Threats to Validity

**Internal validity:**

- Localhost is not a real distributed network
- OS scheduling can introduce variance
- Python/runtime effects can introduce noise

**External validity:**

- Single model, single protocol, CPU-only, batch size 1

**Construct validity:**

- The benchmark measures the full cost of introducing a service boundary, not the marginal cost of an additional hop

**Conclusion validity:**

- Strong repetition reduces risk of weak conclusions
- Multiple comparisons should still be acknowledged

---

## 8. Implementation Roadmap

### Phase 0: Project Structure

```
opus/
├── proto/
│   └── inference.proto
├── src/
│   ├── __init__.py
│   ├── models/
│   │   ├── resnet_splits.py
│   │   └── validation.py
│   ├── services/
│   │   ├── service_b.py
│   │   └── service_b_runner.py
│   ├── benchmark/
│   │   ├── config.py
│   │   ├── timer.py
│   │   ├── runner.py
│   │   ├── warmup.py
│   │   ├── cpu_stabilisation.py
│   │   └── logging.py
│   ├── analysis/
│   │   ├── statistics.py
│   │   └── plots.py
│   └── client/
│       ├── monolithic.py
│       └── split_client.py
├── configs/
│   └── rq1/
│       └── 1.1/
│           ├── rq1_1_fully_controlled.yaml
│           ├── rq1_1_threaded.yaml
│           └── rq1_1_experimental.yaml
├── results/
├── run_experiment.py
├── run_analysis.py
├── build_proto.py
├── requirements.txt
└── README.md
```

### Phase 1: Model Splitting Infrastructure

1. Define split points for the 4 coarse boundaries.
2. Validate functional equivalence.
3. Record intermediate tensor shapes and sizes.

### Phase 2: gRPC Communication Layer

1. Define proto schema.
2. Implement Service B.
3. Implement split client.
4. Validate end-to-end correctness for all 4 split points.

### Phase 3: Timing Instrumentation

Implement timing for:

- end-to-end latency (`end_to_end_ms`)
- Service A compute (`service_a_compute_ms`)
- boundary-crossing interval (`boundary_crossing_ms`)
- Service B compute (`service_b_compute_ms`, server-reported via gRPC response)
- Diagnostic sub-timings (`request_serialize_ms`, `request_deserialize_ms`, `response_serialize_ms`, `response_deserialize_ms`)

Validate that intervals are sensible and non-negative.

### Phase 4: Benchmark Orchestrator

- Config loading (`src/benchmark/config.py`)
- CPU-behaviour stabilisation (`src/benchmark/cpu_stabilisation.py`)
- Process management (Service B subprocess lifecycle)
- Warmup handling with calibration
- Measurement loop
- 5-round structure with seeded randomised ordering
- Environment metadata capture (`environment.json`)
- Entry points: `run_experiment.py` (benchmark), `run_analysis.py` (post-experiment analysis)

### Phase 5: Warmup Calibration

- Run fixed W = 50 warmup iterations per condition per round
- Monitor trailing-window CV during warmup to detect stabilisation
- Record calibration evidence in `warmup_calibration.json`
- Log warning if stabilisation not reached within W iterations

### Phase 6: Main Experiment Execution

- Run R = 5, M = 200, plus warmup
- Spot-check raw data after rounds
- Do not change parameters after seeing results unless a full rerun is justified and documented

### Phase 7: Analysis and Reporting

- Compute summary statistics (`condition_summaries.csv`, `round_summaries.csv`)
- Compute overhead relative to monolith (`cross_condition.csv`)
- Compute effect sizes with caveat (`effect_sizes.csv`)
- Compute cross-round consistency (`round_consistency.json`)
- Apply carry-forward rule (`carry_forward.json`)
- Generate plots (`plots/latency_boxplot.png`, `latency_violin.png`, `overhead_vs_activation.png`, `stationarity.png`)
- Generate thesis-facing report (`report.md`)

### Implementation Constraints

- Minimal dependencies
- Deterministic config-driven behavior
- No premature optimization
- Incremental validation before scaling up

---

## Appendix A: Literature Grounding

### Distributed / Partitioned DNN Inference

**Kang et al. (2017), "Neurosurgeon":** Relevant because it shows that split-point choice depends on both compute cost and intermediate data transfer.

**Jeong et al. (2018), "IONN":** Relevant because it highlights that communication-related costs are not always cleanly linear and may include framework effects.

**Hu & Krishnamachari (2020), "DADS":** Relevant because it emphasizes the need to distinguish compute balance and transfer burden when evaluating split points.

### Systems Benchmarking Methodology

**Jain (1991), "The Art of Computer Systems Performance Analysis":** Relevant for controlled-factor design, warmup handling, repeated trials, and statistical reporting.

**Lilja (2000), "Measuring Computer Performance":** Relevant for measurement overhead awareness, distribution-aware statistics, and careful interpretation.

**van der Kouwe et al. (2018), "Benchmarking Crimes":** Relevant for avoiding common experimental failures such as poor warmup, insufficient repetitions, or unfair comparisons.

### Fair Comparison Principles

**Mytkowicz et al. (2009):** Relevant for understanding how environmental factors can bias measurement.

**Curtsinger & Berger (2013), "STABILIZER":** Relevant for highlighting how repeated measurements and robust comparison procedures matter for fair evaluation.

---

## Appendix B: Design Decision Record

| Decision                      | Choice                            | Alternative                       | Rationale                                                           |
| ----------------------------- | --------------------------------- | --------------------------------- | ------------------------------------------------------------------- |
| Main split scope              | 4 coarse architectural boundaries | 1 split or exhaustive layer sweep | Supports thesis-facing selection without overbroad characterization |
| Stem split                    | Excluded from main sweep          | Included in main sweep            | Better thesis story and less trivial domination of results          |
| Monolithic baseline           | Direct function call              | gRPC-wrapped monolith             | Measures total boundary introduction cost                           |
| Communication-adjacent metric | `boundary_crossing_ms`            | "communication overhead"          | More honest and less ambiguous                                      |
| Primary ranking metric        | Mean latency                      | Median latency                    | Better aligned with carry-forward selection logic                   |
| Secondary robustness metrics  | Median, p95, std                  | Mean only                         | Preserves stability and variability interpretation                  |
| Compute device                | CPU                               | GPU                               | Avoids GPU confounds                                                |
| Locality                      | Localhost (127.0.0.1)             | Networked deployment              | Isolates boundary effects                                           |
| Batch size                    | 1                                 | Larger batches                    | Measures per-request cost cleanly                                   |
| Repetition structure          | 5 rounds × 200 iterations         | Smaller benchmark                 | Stronger statistical discipline                                     |
| Ordering                      | Randomized per round (seeded)     | Fixed order                       | Reduces temporal confounds                                          |
| Threading (thesis mode)       | 1 intra-op, 1 inter-op thread     | Multi-threaded                    | Eliminates thread-pool scheduling variance                          |
| CPU affinity (thesis mode)    | 1 physical core, SMT excluded     | Multi-core                        | Eliminates migration and cache thrashing                            |

---

> **Summary of main changes from prior version:**
>
> - RQ1.1 is now a **selection study**
> - The main sweep is now **4 coarse boundaries**, not 5
> - "communication overhead" is replaced by **`boundary_crossing_ms`**
> - **Mean** latency is now primary for selection
> - The **strong 5 × 200 repetition structure** stays
>
> **Reconciled with codebase (16 April 2026):**
>
> - Config paths updated to `configs/rq1/1.1/` (nested layout)
> - Project structure updated to match actual directory tree
> - Benchmark conditions table now describes the **fully controlled** profile as thesis-facing default
> - `openblas_num_threads` added to threading controls
> - Three config profiles (fully controlled, threaded, experimental) clarified with accurate descriptions
> - Warmup calibration: noted that all W iterations always execute and CV uses population std
> - Parity validation: clarified two-stage enforcement (local + gRPC round 1)
> - Repetition pseudo-code updated to match actual implementation
> - Design decision record extended with threading and affinity choices
> - Server-side diagnostic timings described in boundary-crossing metric section
